package com.example.mismapas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void irAvenida(View v){
        Intent i = new Intent(this, MapsActivity.class);
        //enviamos los valores al activity map para las coordenadas
        //de cada sitio iconico
        i.putExtra("lugar",1);
        startActivity(i);
    }
    public void irRio(View v){
        Intent i = new Intent(this, MapsActivity.class);
        //enviamos los valores al activity map para las coordenadas
        //de cada sitio iconico
        i.putExtra("lugar", 2);
        startActivity(i);
    }
    public void irIglesia(View v){
        Intent i = new Intent(this, MapsActivity.class);
        //enviamos los valores al activity map para las coordenadas
        //de cada sitio iconico
        i.putExtra("lugar", 3);
        startActivity(i);
    }
    public void irEstadio(View v){
        Intent i = new Intent(this, MapsActivity.class);
        //enviamos los valores al activity map para las coordenadas
        //de cada sitio iconico
        i.putExtra("lugar", 4);
        startActivity(i);
    }
}//main