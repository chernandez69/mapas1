package com.example.mismapas;

import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    //declaramos variable para recibir el valor del parametro
    //enviado desde la activity main
    public int valor=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        //obtengo los valores para las coordenadas
        Bundle parametros = this.getIntent().getExtras();
        valor = parametros.getInt("lugar");
    }//oncreate

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        switch (valor){
            case 1:
                //especificar puntero para monteria colombia avenida primera
                LatLng avenida = new LatLng(8.7566821797428, -75.88788181543352);
                mMap.addMarker(new MarkerOptions().position(avenida).title("Marker in Av 1"));
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(avenida,40));
               // mMap.moveCamera(CameraUpdateFactory.newLatLng(avenida));
                break;
            case 2:
                //especificar puntero para monteria colombia rio sinu
                LatLng rio = new LatLng(8.756602651397841, -75.88922828435899);
                mMap.addMarker(new MarkerOptions().position(rio).title("Marker in Rio Sinu"));
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(rio,15));
                break;
            case 3:
                //especificar puntero para monteria colombia catedral san jeronimo
                LatLng iglesia = new LatLng(8.755415026090231, -75.88649779558183);
                mMap.addMarker(new MarkerOptions().position(iglesia).title("Marker in Catedral"));
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(iglesia,40));
                break;
            case 4:
                //especificar puntero para monteria colombia estadio 18 junio
                LatLng estadio = new LatLng(8.765928559363713, -75.86777061223984);
                mMap.addMarker(new MarkerOptions().position(estadio).title("Marker in est 18 junio"));
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(estadio,40));
                break;
            default:
                //especificar puntero para monteria colombia avenida primera
                LatLng colombia = new LatLng(8.755643008028166, -75.88488578796388);
                mMap.addMarker(new MarkerOptions().position(colombia).title("Marker in Colombia"));
                mMap.moveCamera(CameraUpdateFactory.newLatLng(colombia));
                break;
        }//switch
    }//on map ready
}//mapsactivity